﻿using UnityEngine;

namespace WrappingRopeLibrary.Events
{
    public delegate void Mouse(Vector2 position);

}
